# comms.py — ASCII-only UART daisy-chain receiver / sender
#
# Packet format:  AZ{src:X}{dest:X}{type:X}{payload_hex}YB
#   src / dest : single hex digit, range 1-F (1-9 and A-F)
#   type       : single hex digit (0-F)
#   payload    : zero or more bytes, each encoded as two hex chars
#
# Discard rules (one print then blank line):
#   • Invalid header (not AZ)
#   • Invalid end    (not YB)
#   • Invalid src ID
#   • Invalid dest ID
#   • Message too long

import time
from config import (
    MY_ID, DEST_ID,
    MAX_DATA_SIZE,
    BAUDRATE,
    MSG_TYPE_SPEED, MSG_TYPE_ORIENTATION, MSG_TYPE_CUSTOM,
    MSG_TYPE_ACK, MSG_TYPE_ERROR,MSG_TYPE_IMU_ERR
)
from machine import Pin

_VALID_IDS = set(range(1, 7))    # 1-6


# ------------------------------------------------------------------ #
#  Packet builder                                                      #
# ------------------------------------------------------------------ #

def build_packet(src, dest, msg_type, payload=''):
    """Build an ASCII packet: AZ{src}{dest}{type}{payload}YB"""
    if len(payload) > MAX_DATA_SIZE - 1:
        print("[TX] payload too long (%d > %d), dropped" % (len(payload), MAX_DATA_SIZE - 1))
        print("")
        return None
    return ('AZ%d%d%d%sYB' % (src, dest, msg_type, payload)).encode()


# ------------------------------------------------------------------ #
#  Helpers                                                             #
# ------------------------------------------------------------------ #

def _split16(value):
    v = int(value) & 0xFFFF
    return (v >> 8) & 0xFF, v & 0xFF

def _float_to_uint16(f):
    return int(f) & 0xFFFF


# ------------------------------------------------------------------ #
#  DaisyNode                                                           #
# ------------------------------------------------------------------ #

class DaisyNode:

    def __init__(self, uart, imu):
        self._uart      = uart
        self._imu       = imu
        self._buf       = bytearray()
        self._receiving = False
        self._fwd_queue = []
        self._led       = Pin(12, Pin.OUT, value=0)

    def _log_packet(self, pkt):
        print("[Actual TX] %s" % pkt.decode())

    def _uart_write(self, pkt):
        was_on = self._led.value()
        self._led.on()
        self._uart.write(pkt)
        time.sleep_ms((len(pkt) * 10 * 1000 // BAUDRATE) + 2)
        while self._uart.any():
            self._uart.read(self._uart.any())
        self._led.value(was_on)

    # ============================================================== #
    #  PUBLIC INTERFACE                                                #
    # ============================================================== #

    def receiver_step(self):
        while self._uart.any():
            byte = self._uart.read(1)[0]

            if not self._receiving:
                if len(self._buf) == 0:
                    if byte == 0x41:            # 'A' — possible start
                        self._buf.append(byte)
                    # else: silently ignore junk bytes
                elif len(self._buf) == 1:
                    if byte == 0x5A:            # 'Z' — valid header AZ
                        self._buf.append(byte)
                        self._receiving = True
                    elif byte == 0x41:          # another 'A' — restart
                        self._buf = bytearray([byte])
                    else:
                        print("[RX] invalid header: A+0x%02X — expected 'AZ', discarded" % byte)
                        print("")
                        self._buf = bytearray()
                continue

            # Collecting packet body
            self._buf.append(byte)

            # AZ mid-stream = new packet start; discard partial bad packet
            if byte == 0x5A and len(self._buf) > 4 and self._buf[-2] == 0x41:
                print("[RX] invalid end — new packet start mid-stream, discarded")
                print("")
                self._buf = bytearray([0x41, 0x5A])
                self._receiving = True
                continue

            if byte in (0x0D, 0x0A):           # \r or \n terminates line
                stripped = bytes(self._buf).rstrip(b'\r\n')
                if len(stripped) >= 2 and stripped[-2:] == b'YB':
                    self._process_ascii(stripped)
                else:
                    tail = stripped[-2:] if len(stripped) >= 2 else stripped
                    print("[RX] invalid end: %r — expected 'YB', discarded" % tail)
                    print("")
                self._reset()
                continue

            # Short packet ending in YB (no line terminator)
            if len(self._buf) >= 4 and self._buf[-2:] == bytearray([0x59, 0x42]):
                self._process_ascii(bytes(self._buf))
                self._reset()
                continue

            # Guard against runaway packets
            if len(self._buf) > MAX_DATA_SIZE * 2 + 6:   # AZ+src+dest+type+hex_payload+YB
                print("[RX] message too long (>%d chars), discarded" % (MAX_DATA_SIZE * 2 + 6))
                print("")
                self._reset()

    def sender_step(self):
        while self._fwd_queue:
            self._uart.write(self._fwd_queue.pop(0))

    # ============================================================== #
    #  RECEIVER INTERNALS                                              #
    # ============================================================== #

    def _reset(self):
        self._buf       = bytearray()
        self._receiving = False

    def _process_ascii(self, raw):
        try:
            text = raw.decode()
        except Exception as e:
            print("[RX] decode error: %s — discarded" % str(e))
            print("")
            return

        # Header already validated in receiver_step; double-check end
        if not text.endswith('YB'):
            print("[RX] invalid end — expected 'YB', discarded")
            print("")
            return

        middle = text[2:-2]     # strip leading AZ and trailing YB

        if len(middle) < 3:
            print("[RX] packet too short, discarded")
            print("")
            return

        try:
            src      = int(middle[0], 16)
            dest     = int(middle[1], 16)
            msg_type = int(middle[2], 16)
        except ValueError:
            print("[RX] non-hex src/dest/type chars, discarded")
            print("")
            return

        if src not in _VALID_IDS:
            print("[RX] invalid src=%d — not in range 1-6, discarded" % src)
            print("")
            return
        if dest not in _VALID_IDS:
            print("[RX] invalid dest=%d — not in range 1-6, discarded" % dest)
            print("")
            return

        if src == MY_ID:
            print("[RX] own echo src=%d — discarded" % src)
            print("")
            return

        payload_str = middle[3:]
        if len(payload_str) > MAX_DATA_SIZE - 1:
            print("[RX] message too long (%d bytes, max %d), discarded"
                  % (len(payload_str), MAX_DATA_SIZE - 1))
            print("")
            return

        data = bytearray([msg_type]) + bytearray(payload_str.encode())

        print("[RX] src=%d dest=%d type=%d payload='%s'"
              % (src, dest, msg_type, payload_str))

        if dest == MY_ID:
            self._dispatch(src, msg_type, payload_str)
        else:
            print("[RX] forwarding src=%d dest=%d" % (src, dest))
            pkt = build_packet(src, dest, msg_type, payload_str)
            if pkt:
                self._fwd_queue.append(pkt)
            print("")

    def _dispatch(self, src, msg_type, payload):
        if msg_type == MSG_TYPE_SPEED:
            self._handle_speed(src, payload)
        elif msg_type == MSG_TYPE_ORIENTATION:
            self._handle_orientation(src, payload)
        elif msg_type == MSG_TYPE_CUSTOM:
            self._handle_custom(src, payload)
        else:
            print("[RX] unknown type=%d from src=%d — sending error" % (msg_type, src))
            self._send_error(src, msg_type)
            print("")

    # ---------------------------------------------------------------- #
    #  Type 2 — Speed request                                           #
    # ---------------------------------------------------------------- #

    def _handle_speed(self, src, payload):
        try:
            speed = self._imu.get_speed()
            self._led.off()
        except Exception as e:
            print("[IMU] get_speed error: %s" % str(e))
            self._send_imu_err(src)
            #speed = 0.0
            return

        print("[RX] type 2 (SPEED) from src=%d  speed=%.4f m/s2" % (src, speed))

        pkt = build_packet(MY_ID, DEST_ID, MSG_TYPE_SPEED, "%.4f" % speed)
        if pkt:
            self._log_packet(pkt)
            self._uart_write(pkt)
        print("")

    # ---------------------------------------------------------------- #
    #  Type 3 — Orientation request                                     #
    # ---------------------------------------------------------------- #

    def _handle_orientation(self, src, payload):
        try:
            roll, pitch, heading = self._imu.get_orientation()
            self._led.off()
        except Exception as e:
            print("[IMU] get_orientation error: %s" % str(e))
            #roll = pitch = heading = 0.0
            self._send_imu_err(src)
            return

        direction_str = self._imu.get_direction()

        print("[RX] type 3 (ORIENTATION) from src=%d  dir=%s  pitch=%.0f  roll=%.0f "
              % (src, direction_str, pitch, roll))

        pkt = build_packet(MY_ID, DEST_ID, MSG_TYPE_ORIENTATION,
                           "%s,%.0f,%.0f" % (direction_str, pitch, roll))
        if pkt:
            self._log_packet(pkt)
            self._uart_write(pkt)
        print("")

    # ---------------------------------------------------------------- #
    #  Type 13 — Custom subsystem message                               #
    # ---------------------------------------------------------------- #

    def _handle_custom(self, src, payload):
        try:
            sys, gyro, accel, mag = self._imu.get_calibration()
            self._led.off()
        except Exception as e:
            print("[IMU] get_calibration error: %s" % str(e))
            #sys = gyro = accel = mag = 0
            self._send_imu_err(src)
            return

        print("[RX] type 13 (STATUS) from src=%d  sys=%d gyro=%d accel=%d mag=%d"
              % (src, sys, gyro, accel, mag))

        pkt = build_packet(MY_ID, DEST_ID, MSG_TYPE_CUSTOM,
                           "%d,%d,%d,%d" % (sys, gyro, accel, mag))
        if pkt:
            print("[TX] type 13 (STATUS) to dest=%d  sys=%d gyro=%d accel=%d mag=%d"
                  % (DEST_ID, sys, gyro, accel, mag))
            self._log_packet(pkt)
            self._uart_write(pkt)
        print("")

    # ---------------------------------------------------------------- #
    #  Error response                                                   #
    # ---------------------------------------------------------------- #

    def _send_error(self, dest, bad_type):
        pkt = build_packet(MY_ID, dest, MSG_TYPE_ERROR, "%d" % bad_type)
        if pkt:
            self._log_packet(pkt)
            self._uart.write(pkt)
            
    # ---------------------------------------------------------------- #
    #  Type 14 — IMU not found                                          #
    # ---------------------------------------------------------------- #

    def _send_imu_err(self, dest):
        self._led.on()
        pkt = build_packet(MY_ID, dest, MSG_TYPE_IMU_ERR, "IMU not found")
        if pkt:
            print("[TX] type 15 (IMU_ERR) to dest=%d" % dest)
            self._log_packet(pkt)
            self._uart_write(pkt)
        print("")
