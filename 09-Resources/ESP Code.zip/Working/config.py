# config.py  — Node / protocol configuration
# Edit the values in this section freely.

# ------------------------------------------------------------------ #
#  NODE IDENTITY                                                       #
# ------------------------------------------------------------------ #
MY_ID   = 3   # This node's source/destination ID (1-6)
DEST_ID = 1   # Default destination for our own outgoing messages

# ------------------------------------------------------------------ #
#  UART                                                                #
# ------------------------------------------------------------------ #
UART_ID  = 2
BAUDRATE = 9600
TX_PIN   = 18
RX_PIN   = 17

# ------------------------------------------------------------------ #
#  I2C (BNO055)                                                        #
# ------------------------------------------------------------------ #
I2C_ID  = 0
SCL_PIN = 41
SDA_PIN = 42

# ------------------------------------------------------------------ #
#  PROTOCOL FRAME                                                      #
# ------------------------------------------------------------------ #
START_BYTE_1     = 0x41
START_BYTE_2     = 0x5A
END_BYTE_1       = 0x59
END_BYTE_2       = 0x42
START_BYTES      = bytes([START_BYTE_1, START_BYTE_2])
END_BYTES        = bytes([END_BYTE_1,   END_BYTE_2])
# These four values must never appear in the payload field
FRAME_BYTES      = (START_BYTE_1, START_BYTE_2, END_BYTE_1, END_BYTE_2)

FULL_PACKET_SIZE = 64   # 2 start + src + dest + 58 data + 2 end
MAX_DATA_SIZE    = 58   # bytes 4-61 inclusive

# ------------------------------------------------------------------ #
#  CLASS MESSAGE TYPES  (byte 4 of the packet, i.e. data[0])           #
# ------------------------------------------------------------------ #
# Types this node must handle:
MSG_TYPE_SPEED       = 2    # Request: send speed value
MSG_TYPE_ORIENTATION = 3    # Request: send orientation (roll, pitch, heading)
MSG_TYPE_CUSTOM      = 13   # Custom message type for this subsystem
MSG_TYPE_IMU_ERR     = 14       # IMU not found error reply.

# Error / ACK types used internally when we generate responses:
MSG_TYPE_ACK         = 0x01  # Generic acknowledgement  (type 1 used as ACK)
MSG_TYPE_ERROR       = 0x04  # Error response for unknown types

# ------------------------------------------------------------------ #
#  TIMING                                                              #
# ------------------------------------------------------------------ #
# Maximum rate at which this node transmits its own packets.
# Increase or decrease freely; forwarding is always immediate.
SEND_INTERVAL_MS = 500
