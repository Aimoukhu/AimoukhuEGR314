# imu.py  — BNO055 wrapper
#
# Exposes two public methods matching the two request types we handle:
#   get_speed()       -> float  (magnitude of linear acceleration, m/s²)
#   get_orientation() -> (roll, pitch, heading)  all in degrees (floats)

import math
from machine import Pin, I2C
import time
from bno055 import BNO055, NDOF_MODE
from config import I2C_ID, SCL_PIN, SDA_PIN


class IMU:
    def __init__(self):
        i2c = I2C(I2C_ID, scl=Pin(SCL_PIN), sda=Pin(SDA_PIN), freq=400000)
        self._imu = BNO055(i2c)
        self._imu.mode(NDOF_MODE)
        time.sleep(1)   # allow sensor to stabilise after mode change

    # ---------------------------------------------------------------- #
    #  MSG_TYPE_SPEED (type 2)                                           #
    #  Returns the magnitude of linear acceleration in m/s².            #
    # ---------------------------------------------------------------- #
    def get_speed(self):
        """
        Read linear acceleration and return its vector magnitude (m/s²).
        Linear acceleration excludes gravity, so at rest this is ~0.
        Scaled ×100 and clamped to uint16 for transport.
        """
        self._imu.iget(0x28)  # LIN_ACC_DATA register
        ax = self._imu.x / 100.0   # BNO055 reports in 1/100 m/s²
        ay = self._imu.y / 100.0
        az = self._imu.z / 100.0
        magnitude = math.sqrt(ax * ax + ay * ay + az * az)
        return magnitude   # float, m/s²

    # ---------------------------------------------------------------- #
    #  MSG_TYPE_ORIENTATION (type 3)                                     #
    #  Returns (roll, pitch, heading) in degrees.                        #
    # ---------------------------------------------------------------- #
    def get_orientation(self):
        """
        Read Euler angles from the BNO055 fusion output.
        Returns (roll, pitch, heading) as floats in degrees.

        BNO055 register 0x1A layout (via iget):
            imu.x = heading  0 – 360 °
            imu.y = roll    -90 – +90 °
            imu.z = pitch  -180 – +180 °
        Raw register values are 1/16 degree per LSB.
        """
        self._imu.iget(0x1A)  # EULER_DATA register
        heading = self._imu.x / 16.0
        roll    = self._imu.y / 16.0
        pitch   = self._imu.z / 16.0
        return roll, pitch, heading
    
    def get_direction(self):
        """
        Returns a cardinal direction string based on heading.
        Heading 0/360 = North, 90 = East, 180 = South, 270 = West.
        """
        self._imu.iget(0x1A)
        heading = self._imu.x / 16.0

        if heading < 22.5 or heading >= 337.5:
            return "N"
        elif heading < 67.5:
            return "NE"
        elif heading < 112.5:
            return "E"
        elif heading < 157.5:
            return "SE"
        elif heading < 202.5:
            return "S"
        elif heading < 247.5:
            return "SW"
        elif heading < 292.5:
            return "W"
        elif heading < 337.5:
            return "NW"
        
    def get_calibration(self):
        """
        Returns (sys, gyro, accel, mag) calibration status, each 0-3.
        0 = uncalibrated, 3 = fully calibrated.
        """
        cal = self._imu._read(0x35)
        sys   = (cal >> 6) & 0x03
        gyro  = (cal >> 4) & 0x03
        accel = (cal >> 2) & 0x03
        mag   =  cal       & 0x03
        return sys, gyro, accel, mag
