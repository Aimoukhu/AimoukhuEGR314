# main.py  — entry point
from machine import UART, Pin
from config import UART_ID, BAUDRATE, TX_PIN, RX_PIN
from imu import IMU
from comms import DaisyNode
import sys 
import select
import time

# ---- UART ----
uart = UART(UART_ID, baudrate=BAUDRATE, tx=Pin(TX_PIN), rx=Pin(RX_PIN))
# Flush any garbage that accumulated on RX during power-up
time.sleep_ms(10)
while uart.any():
    uart.read(uart.any())

# ---- IMU ----
imu = IMU()

# ---- Protocol node ----
node = DaisyNode(uart, imu)

# def parse_and_send(uart, line):
#     try:
#         parts = line.strip().split()
#         if len(parts) != 64:
#             print("[CMD] need exactly 64 bytes, got %d" % len(parts))
#             return
#         pkt = bytes([int(b, 16) for b in parts])
#         uart.write(pkt)
#         print("[CMD] sent: %s" % line.strip())
#     except ValueError:
#         print("[CMD] invalid hex input")

def parse_and_send(uart, line):
    try:
        line = line.strip()

        # Expect plain ASCII string like: AZ133YB
        if not line.startswith("AZ"):
            print("[CMD] missing AZ start")
            return

        if not line.endswith("YB"):
            print("[CMD] missing YB end")
            return

        # Send exactly as ASCII text
        pkt = line.encode("ascii")

        uart.write(pkt)
        time.sleep_ms(10)

        print("[CMD] sent ASCII: %s" % line)

    except Exception as e:
        print("[CMD] error:", e)
        
        
# ---- Main loop ----
# while True:
#     if uart.any():
#         data = uart.read()
#         print(data)
while True:
    node.receiver_step()   # drain RX FIFO; forward or process packets
    node.sender_step()     # flush forward queue; then maybe TX own data
    #print(imu.get_calibration())
    
    if select.select([sys.stdin], [], [], 0)[0]:
        line = sys.stdin.readline().strip()
        if line:
            node._process_ascii(line.encode())